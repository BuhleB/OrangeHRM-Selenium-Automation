class Config:
    BASE_URL = "https://opensource-demo.orangehrmlive.com/"
    USERNAME = "Admin"
    PASSWORD = "admin123"
    IMPLICIT_WAIT = 10
    EXPLICIT_WAIT = 20